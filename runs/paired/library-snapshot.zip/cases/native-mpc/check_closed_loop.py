"""Recompute exported metrics and render the independent native SLX traces."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    output = parser.parse_args().out
    summary = json.loads((output/"report.json").read_text("utf-8-sig"))
    actual = {}
    columns = [("original", "Original", "#454b55"), ("archive_tuned", "Archive tuned", "#bb622f"),
               ("corrected", "Bounded MPC", "#087e75")]
    for scenario in ("design","independent_step"):
        for key, _, _ in columns:
            data = np.genfromtxt(output/f"{scenario}-{key.replace('_','-')}.csv",names=True,delimiter=",")
            ref = summary[scenario][key]
            np.testing.assert_allclose(np.diff(data["t"]),summary["sample_time_s"],rtol=0,atol=1e-12)
            np.testing.assert_allclose(data["u"]-data["previous"],data["du"],rtol=0,atol=1e-12)
            err = data["r"]-data["y"]
            computed = {"rmse":np.sqrt(np.mean(err**2)), "rms_u":np.sqrt(np.mean(data["u"]**2)),
                        "peak_u":np.max(np.abs(data["u"])),"peak_du":np.max(np.abs(data["du"]))}
            for metric, value in computed.items():
                np.testing.assert_allclose(value,ref[metric],rtol=0,atol=1e-11)
            if key=="corrected":
                assert computed["peak_u"]<=2+1e-10 and computed["peak_du"]<=.2+1e-10
            if scenario=="independent_step":
                actual[key]=data
    fig,axes=plt.subplots(3,1,figsize=(8,5.9),sharex=True,layout="constrained")
    fig.suptitle("Independent step on the original second-order Simulink plant",fontsize=13)
    axes[0].step(actual["original"]["t"],actual["original"]["r"],where="post",
                 color="black",ls=":",lw=1.4,label="Reference")
    for key,label,color in columns:
        data=actual[key]
        for ax,field in zip(axes,("y","u","du")):
            ax.plot(data["t"],data[field],lw=1.4,color=color,label=label)
    for ax,title in zip(axes,("Position","Actuator input","Input increment")):
        ax.set_ylabel(title); ax.grid(alpha=.2)
        ax.spines[["top","right"]].set_visible(False)
    for ax,bound in zip(axes[1:],(2,.2)):
        for sign in (-1,1):
            ax.axhline(sign*bound,ls="--",color="#75808c",lw=.8)
    axes[0].legend(ncol=4,fontsize=8,loc="lower left")
    axes[-1].set(xlabel="Time (s)",xlim=(0,8))
    fig.savefig(output/"independent-step.png",dpi=155)
    plt.close(fig)
    print("Six native trajectories reproduced the reported metrics and bounds.")


if __name__=="__main__":
    main()
