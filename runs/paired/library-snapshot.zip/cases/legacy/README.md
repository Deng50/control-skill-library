# 原始案例、修正版、可运行实现和模板

| 来源 | 在本库的用途 | 验证范围 |
|---|---|---|
| 二阶 MPC_QP.m、同名顶层与子目录对象 | 增量矩阵错误机制反例、四参数辨识、六参数误用防护 | 新实现与独立递推、原 SLX 数据回放均已运行 |
| 恒功率热过程的旧 Skill 和训练约定 | 用显式 C/G/Ta 自编解析采样与 PINN/NN，暴露导数缩放和初值误差 | 仿真与导出重载已运行 |
| pgac/thermal-management-model.py、nmpc_casadi_align_5s_fix_torque.py、system_test_align_delay.py | 热对象与热惯性/延迟、NMPC 作专家的工程参考 | 原对象局部一步线性化已运行；完整 NMPC 闭环未在本轮回放 |
| pgac_auto_train_agent_v1/kernels/pgac_core.py | 读取 Actor、Perception、ReferenceBank、MPCCritic.rollout_J 的连接 | 实跑热内核三步代价和梯度，测量感知层调用数；热管理历史权重保留原位。弹簧对象的模仿到 PGAC 两分支另行实跑 |
| spring-damper-ppt-20261030 | 复用模型、控制工况、专家工况及划分，新生成闭环数据；另直接导入存档 expert.npz 模仿训练 | 新数据与存档数据各有独立报告，历史优化策略数值未作为本次训练结果 |
| 电池等效电路辨识、DEKF 热状态、EGR、转速、PID/ADRC/LQR | 选择估计器、基线及发现信息泄漏的知识条目 | 仅存档和方法参考，缺面向同对象的独立闭环复验 |
| 遗传算法热模型参数辨识 | 学习参数估计与热模型表达 | 原目录附名为“版权声明.txt”的再分发限制；此库仅含来源指纹。第三方源码、模型和历史权重仍在原处 |

面向新对象时，按 cases/thermal/table.json 改字段、单位、时间与窗口，按 cases/spring/controller.json 和 expert.json 改场景；替换控制器的接入形式见调优 Skill。新的方程残差、观测器、硬动作变化率、工业级失效回退或真实设备时延需要针对对象实例化和验证。自编实现与源数据、模型及配置的权利来源分别记录，外发原材料按所属方授权处理。[文件级目录与 SHA-256](../../sources.json)
